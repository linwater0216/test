a=tuple(('B',0,2,3,2,5,5,1))
print(a[5:8])