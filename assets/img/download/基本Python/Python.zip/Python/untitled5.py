nowyear = int(input("Enter the year:"))
if (nowyear%4 == 0 and nowyear%100 != 0) or nowyear%400 == 0:
    year=nowyear%7-1
    pyear=366
else:
    year=nowyear%7
    pyear=365
for i in range(1,13):
    print("  ",i,"月")
    if(i==1 or i==3 or i==5 or i==7 or i==8 or i==10 or i==12):
        for j1 in range(1,32):
            print(j1,"號"," ","星期",end=' ')
            if(year%7==0):
                print(year%7+7)
            else:
                print(year%7)
            year=year+1
    else:
        if(i==2 and pyear==366):
            for j2 in range(1,30):
                print(j2,"號"," ","星期",end=' ')
                if(year%7==0):
                    print(year%7+7)
                else:
                    print(year%7)
                year=year+1
        if(i==2 and pyear==365):
            for j3 in range(1,29):
                print(j3,"號"," ","星期",end=' ')
                if(year%7==0):
                    print(year%7+7)
                else:
                        print(year%7)
                year=year+1
        if(i==4 or i==6 or i==9 or i==11):
            for j4 in range(1,31):
                print(j4,"號"," ","星期",end=' ')
                if(year%7==0):
                    print(year%7+7)
                else:
                    print(year%7)
                year=year+1

    


