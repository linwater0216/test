i=3
t=0
while i<6:
    t=t+2**i
    i=i+1
print(t)