n = input('學號:')
l=list(str(n))
print(ord(l[0])," ",ord(l[1])," ",l[2])